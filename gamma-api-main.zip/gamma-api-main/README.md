gamma-api.cc api methods leaked i will be leaking a shit ton of api methods soon
